import axios from "axios";
import React, { useEffect, useRef, useState } from "react";
import { Overlay, Popover } from "react-bootstrap";
import DataTable from "react-data-table-component";
import { FaEye, FaPencilAlt, FaTrash } from "react-icons/fa";
import { useDispatch, useSelector } from "react-redux";
import { toast, ToastContainer } from "react-toastify";
import { apiPost } from "../../config/apiConfig";
import { TRANSPORT_MONTH_DELETE } from "../../config/BaseUrl";
import { tryFetchTransportSettingTableData } from "../../slices/settings/transportSettingSlice";
import TransportEditModal from "./TransportEditModal";
import {
  tryFetchPickupPointListData,
  tryFetchRouteListData,
} from "../../slices/transport/transportSlice";
function TransportSettingTable() {
  const transportSettingData: any = useSelector(
    (state: any) => state.transportsetting
  );
  const TransportLists: any = useSelector((state: any) => state.transport);
  const dispatch = useDispatch();
  const ref = useRef(null);
  const [editModal, setEditModal]: any = useState(false);
  const [editRowData, setEditRowData]: any = useState(null);
  const [itemId, setItemId] = useState("");
  const [show, setShow] = useState(false);
  const [target, setTarget] = useState(null);
  const handleModel = (row: any) => {
    // var data = {
    //   year: transportSettingData.transportSettingTableData?.academic_year,
    //   route: row?.route_id,
    // };
    // dispatch(tryFetchPickupPointListData(data));
    setEditRowData(transportSettingData?.transportSettingTableData);
    setEditModal(true);
  };
  const handleDeleteModal = (event: any, id: any) => {
    console.log("row month", id);
    setShow(true);
    setTarget(event.target);
    setItemId(id);
  };
  async function handleDelete(id: any) {
    console.log("delete initiated");
    try {
      var token = localStorage.getItem("token") as string;
      var bodyFormData = new FormData();
      bodyFormData.append("Authorization", token);
      bodyFormData.append(
        "id",
        transportSettingData?.transportSettingTableData?.id
      );
      bodyFormData.append("month", id);

      let resp: any = await apiPost(TRANSPORT_MONTH_DELETE, bodyFormData);
      console.log("DELETE transport setting datas  is ", resp);
      if (resp.response.data.status === 200 && resp.response.data.data) {
        setShow(false);
        dispatch(
          tryFetchTransportSettingTableData(
            transportSettingData?.transportSettingTableData?.student_id
          )
        );
        toast.error("Transport Details Deleted");
      } else {
        alert("Something happened please try again");
      }
    } catch (error) {
      if (axios.isAxiosError(error)) {
        console.log("error message: ", error.message);
        return error.message;
      } else {
        console.log("unexpected error: ", error);
        return "An unexpected error occurred";
      }
    }
  }
  const columns = [
    {
      name: "Month",
      selector: (row: any) => row.month,
      sortable: true,
    },
    {
      name: "Ways",
      selector: (row: any) =>
        row.transport_type === "1" ? "One-Way" : "Two-way",
      sortable: true,
    },
    {
      name: "Route",
      selector: (row: any) => row.route_name,
      sortable: true,
    },
    {
      name: "Pickup Point",
      selector: (row: any) => row.pick_up_name,
      sortable: true,
    },
    {
      name: "Fee",
      selector: (row: any) => row.fee,
      sortable: true,
    },
    {
      name: "Tuition Fee",
      selector: (row: any) => row.akash,
      sortable: true,
    },
    {
      name: "Action",
      cell: (row: any) => (
        <div className="settingsButtonsContainer">
          <div
            className="settings-btn editBtn"
            onClick={() => handleModel(row)}
          >
            <FaPencilAlt size={12} />
          </div>
          <div
            className="settings-btn deleteBtn"
            onClick={(e) => handleDeleteModal(e, row.month_id)}
          >
            <FaTrash size={12} />
          </div>
          {/* <div className="settings-btn viewBtn">
            <FaEye size={12} />
          </div> */}
        </div>
      ),
    },
  ];
  useEffect(() => {
    dispatch(tryFetchRouteListData());
  }, []);
  return (
    <>
      <ToastContainer />
      <div className="page-inner-content" ref={ref}>
        <DataTable
          columns={columns}
          data={transportSettingData?.transportSettingTableData?.settings}
        />

        <TransportEditModal
          modalOpen={editModal}
          setOpen={setEditModal}
          datas={editRowData}
        />
        <Overlay
          show={show}
          target={target}
          placement="left"
          container={ref}
          containerPadding={20}
        >
          <Popover id="popover-basic">
            <Popover.Header as="h3">Confirm Delete?</Popover.Header>
            <Popover.Body>
              Are you sure you want to delete fee for this month?
              <div className="d-flex gap-3 mt-3">
                <button className="btn-view" onClick={() => setShow(false)}>
                  No
                </button>
                <button
                  className="btn-view"
                  onClick={() => handleDelete(itemId)}
                >
                  Yes
                </button>
              </div>
            </Popover.Body>
          </Popover>
        </Overlay>
      </div>
    </>
  );
}

export default TransportSettingTable;
