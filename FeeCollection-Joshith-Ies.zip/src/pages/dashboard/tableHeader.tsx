import React, { useEffect, useState } from "react";
import { Row, Col, Modal } from "react-bootstrap";
import { FaCoins } from "react-icons/fa";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";

import FeeHistoryModal from "./FeeHistoryModal";
function TableHeader() {
  const params = useParams();
  const feesData: any = useSelector((state: any) => state.feeTable);
  const [show, setShow]: any = useState(false);
  const [headerComponent, setHearderComponent] = useState([
    {
      name: "Demand",
      icon: <FaCoins size={20} />,
      color: "#E1F0FF",
      iconColor: "#3699FF",
    },
    {
      name: "Collection",
      icon: <FaCoins size={20} />,
      color: "#FFE2E5",
      iconColor: "#F64E60",
    },
    {
      name: "Balance",
      icon: <FaCoins size={20} />,
      color: "#EEE5FF",
      iconColor: "#8950FC",
    },
  ]);

  const handleCollection = (item: any) => {
    if (item.name === "Collection") {
      setShow(true);
      // history(`/fee-history/${feesData.feeData.student_details?.student_id}`);
    }
  };
  return (
    <>
      <Row>
        <Col md={6} className="student-profile-details">
          <div className="student-image">
            <div className="student-image-container">
              <img
                src="https://www.kindpng.com/picc/m/78-786207_user-avatar-png-user-avatar-icon-png-transparent.png"
                alt=""
              />
            </div>
          </div>
          <div className="student-details student-detail-font">
            <span className="bold mb-2">
              {feesData.feeData.student_details?.name}
            </span>
            {feesData.feeData.student_details?.class +
              " " +
              feesData.feeData.student_details?.division +
              " "}
            {feesData.feeData.student_details?.sub_division
              ? feesData.feeData.student_details?.sub_division
              : ""}
          </div>
          <div className="student-class">
            <span className="mb-2 student-detail-font">
              {feesData.feeData.student_details?.old_admission_no} -{" "}
              {feesData.feeData?.academic_year}
              {feesData.feeData?.display_message}
            </span>
            <div className="privilage">
              <span
                className=" student-detail-font "
                style={{
                  color: "yellow",
                  fontWeight: "bold",
                  WebkitTextStroke: "0.05px black",
                  textShadow:
                    "-1px -1px 0 #000, 1px -1px 0 #000, -1px 1px 0 #000, 1px 1px 0 #000",
                }}
              >
                {feesData.feeData.student_details?.student_status?.replace(
                  /\s+/g,
                  ""
                ) === "Suspended"
                  ? "Inactive"
                  : ""}
              </span>
              <span className="student-privilage">
                {feesData.feeData.student_details?.concession_type
                  ? feesData.feeData.student_details?.concession_type
                  : "No special privilage"}
              </span>
            </div>
          </div>
        </Col>
        {params.type ? (
          ""
        ) : (
          <Col md={6} className="fee-overview">
            <Row>
              {headerComponent.map((item) => {
                return (
                  <Col
                    md={4}
                    className="overview"
                    style={{
                      cursor: item.name === "Collection" ? "pointer" : "",
                    }}
                    onClick={() => handleCollection(item)}
                  >
                    <div
                      className="overview-icon"
                      style={{ background: item.color, color: item.iconColor }}
                    >
                      {item.icon}
                    </div>
                    <div className="overview-details">
                      <span className="bold mb-1">
                        {item.name === "Demand"
                          ? feesData.feeData?.demand_amt
                            ? feesData.feeData?.demand_amt
                            : "0"
                          : item.name === "Collection"
                          ? feesData.feeData?.paid_amt
                            ? feesData.feeData?.paid_amt
                            : "0"
                          : item.name === "Balance"
                          ? feesData.feeData?.balance_amt
                            ? feesData.feeData?.balance_amt
                            : "0"
                          : "0"}
                      </span>
                      <span className="overview-title student-detail-font">
                        {item.name}
                      </span>
                    </div>
                  </Col>
                );
              })}
            </Row>
          </Col>
        )}
      </Row>
      <Row>
        <Col md={12} className="history-modal">
          <FeeHistoryModal show={show} setShow={setShow} />
        </Col>
      </Row>
    </>
  );
}

export default TableHeader;
